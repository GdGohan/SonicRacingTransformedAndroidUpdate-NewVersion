import re
import os

def substituir_shaders(arquivo_so, pasta_shaders, novo_arquivo_so):
    with open(arquivo_so, 'rb') as file:
        # Lê todo o conteúdo do arquivo binário
        conteudo = file.read()

    # Regex para identificar códigos de shader no arquivo .so
    shader_pattern = br'(#version \d+.*?}(?:\s*//.*?)*\s*)'
    
    # Encontrar todos os códigos de shader no arquivo
    shaders = re.findall(shader_pattern, conteudo, re.DOTALL)
    
    # Itera sobre cada shader e substitui com o conteúdo dos arquivos de shader
    for i, shader in enumerate(shaders):
        # Define o caminho para o arquivo de shader correspondente na pasta out
        shader_file_path = os.path.join(pasta_shaders, f'shader_{i+1}.glsl')
        
        # Verifica se o arquivo de shader existe
        if os.path.exists(shader_file_path):
            # Lê o conteúdo do arquivo de shader
            with open(shader_file_path, 'rb') as shader_file:
                shader_conteudo = shader_file.read()
            
            # Substitui o shader no conteúdo do arquivo .so pelo conteúdo do arquivo
            conteudo = conteudo.replace(shader, shader_conteudo)
    
    # Salva o conteúdo modificado em um novo arquivo .so
    with open(novo_arquivo_so, 'wb') as file:
        file.write(conteudo)

# Usar a função
substituir_shaders('./libASN_App_Android_10_Unity.so', './out', './out/libASN_App_Android_10_Unity.so')