import re

def extrair_shaders(arquivo_so, pasta_saida):
    with open(arquivo_so, 'rb') as file:
        # Lê todo o conteúdo do arquivo binário
        conteudo = file.read()
        
        # Regex para identificar códigos de shader
        shader_pattern = br'(#version \d+.*?}(?:\s*//.*?)*\s*)'
        
        # Encontrar todos os códigos de shader no arquivo
        shaders = re.findall(shader_pattern, conteudo, re.DOTALL)
        
        # Salvar cada shader em um arquivo separado
        for i, shader in enumerate(shaders):
            nome_arquivo = f'{pasta_saida}/shader_{i+1}.glsl'
            with open(nome_arquivo, 'wb') as shader_file:
                shader_file.write(shader)

# Usar a função
extrair_shaders('./libASN_App_Android_10_Unity.so', './out')