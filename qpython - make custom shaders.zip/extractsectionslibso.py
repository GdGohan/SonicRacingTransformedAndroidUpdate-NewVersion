# pip install pyelftools
from elftools.elf.elffile import ELFFile

def listar_secoes_elf(arquivo_elf):
    with open(arquivo_elf, 'rb') as f:
        elf = ELFFile(f)
        secoes = []

        for secao in elf.iter_sections():
            secoes.append(secao.name)
        
        return secoes

# Exemplo de uso
arquivo_elf = './libASN_App_Android_10_Unity.so'
secoes = listar_secoes_elf(arquivo_elf)

print("Sections found:")
for secao in secoes:
    print(secao)